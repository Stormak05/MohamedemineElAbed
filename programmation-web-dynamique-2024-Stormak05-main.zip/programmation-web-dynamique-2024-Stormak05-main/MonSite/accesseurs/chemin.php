<?= realpath('chemin.php'); ?>
